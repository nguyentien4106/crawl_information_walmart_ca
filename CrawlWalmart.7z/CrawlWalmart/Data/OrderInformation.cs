﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CrawlWalmart.Data
{
    public class OrderInformation
    {
        public string OrderNumber { get; set; }
        public string Status { get; set; }
        public string PurchaseDate { get; set; }
    }
}
